import numpy as np
from flask import Flask, request, render_template
import tensorflow.compat.v2 as tf
from keras.engine.functional import Functional
from keras import models
from keras.models import model_from_json

app = Flask(__name__)

#json_file = open('model.json', 'r')
#loaded_model_json = json_file.read()
#json_file.close()
#model = model_from_json(loaded_model_json)
#model.load_weights("model.h5")


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    json_file = open('model.json', 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    model = model_from_json(loaded_model_json)
    model.load_weights("model.h5")
    features = [float(x) for x in request.form.values()]
    final_features =np.array([features])
    print(final_features)
    print(model.predict([[0,1,0,29,90,255,1,0,2,0,1,0]]))

    prediction =model.predict(final_features)
    print("final features", final_features)
    print("prediction:", prediction)
    output = prediction[0]
    print(output)
    if output < 0.5:
        return render_template('result.html', prediction_text1='THIS POFILE IS FAKE')
    else:
        return render_template('result.html', prediction_text2='THIS PROFILE IS NOT FAKE')


if __name__ == "__main__":
    app.run(debug=True)
